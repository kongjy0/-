/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50712
Source Host           : localhost:3306
Source Database       : site

Target Server Type    : MYSQL
Target Server Version : 50712
File Encoding         : 65001

Date: 2018-03-12 22:05:14
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for apply
-- ----------------------------
DROP TABLE IF EXISTS `apply`;
CREATE TABLE `apply` (
  `a_id` int(11) NOT NULL AUTO_INCREMENT,
  `s_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `starTime` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `endTime` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `a_type` int(255) DEFAULT '0',
  `ext1_int` int(255) DEFAULT NULL,
  `ext2_varchar` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`a_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of apply
-- ----------------------------
INSERT INTO `apply` VALUES ('1', '1', '1', '666', '2018-03-12 23:54:26', '2018-03-22 23:54:30', '0', null, null);
INSERT INTO `apply` VALUES ('2', '1', '3', '666', '2018-03-12 10:17:10', '2018-03-12 10:17:10', '-1', null, null);
INSERT INTO `apply` VALUES ('3', '3', '3', 'qqq', '2018-03-12 10:17:04', '2018-03-12 10:17:04', '1', null, null);
INSERT INTO `apply` VALUES ('9', '1', '3', 'das', '2018-03-12 00:56:21', '2018-03-12 00:56:21', '1', null, null);
INSERT INTO `apply` VALUES ('10', '1', '7', '随便用用', '2018-03-12 21:49:51', '2018-03-12 21:49:51', '1', null, null);
INSERT INTO `apply` VALUES ('12', '3', '7', '再写一个', '2018-03-12 21:49:53', '2018-03-12 21:49:53', '-1', null, null);

-- ----------------------------
-- Table structure for message
-- ----------------------------
DROP TABLE IF EXISTS `message`;
CREATE TABLE `message` (
  `m_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `message` varchar(255) DEFAULT NULL,
  `reply` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`m_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of message
-- ----------------------------
INSERT INTO `message` VALUES ('1', '3', '2018-03-12 16:26:24', '666', null);
INSERT INTO `message` VALUES ('2', '1', '2018-03-12 21:18:32', '666', 'dsadsa');
INSERT INTO `message` VALUES ('4', '3', '2018-03-12 17:20:31', 'wocao', 'das');
INSERT INTO `message` VALUES ('6', '7', '2018-03-12 21:51:30', '刚才时间有点问题 已经修复', '有错就改 值得表扬');

-- ----------------------------
-- Table structure for site
-- ----------------------------
DROP TABLE IF EXISTS `site`;
CREATE TABLE `site` (
  `s_id` int(11) NOT NULL AUTO_INCREMENT,
  `s_name` varchar(255) DEFAULT NULL,
  `requires` varchar(255) DEFAULT NULL,
  `s_type` int(255) DEFAULT '0',
  `ext1_int` int(255) DEFAULT NULL,
  `ext2_varchar` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`s_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of site
-- ----------------------------
INSERT INTO `site` VALUES ('1', '小广场', '院级以上活动', '0', null, null);
INSERT INTO `site` VALUES ('3', '二食堂', '饿了吃饭', '0', null, null);
INSERT INTO `site` VALUES ('4', '学校大门口', '不能随便用', '1', null, null);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) DEFAULT NULL,
  `user_account` varchar(255) DEFAULT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `IDcard` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT '1',
  `ext1_int` int(11) DEFAULT NULL,
  `ext2_varchar` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'admin', 'admin', 'admin', 'admin', '-1', null, null);
INSERT INTO `user` VALUES ('3', 'w', 'www', 'www', 'ww', '2', null, '1491846641253_4159.png');
INSERT INTO `user` VALUES ('5', '321', '321', '321', '321', '2', null, '1491848187932_4868.png');
INSERT INTO `user` VALUES ('7', 'user', 'user', 'user', '123456', '2', null, '1492004449293_6504.png');
SET FOREIGN_KEY_CHECKS=1;
