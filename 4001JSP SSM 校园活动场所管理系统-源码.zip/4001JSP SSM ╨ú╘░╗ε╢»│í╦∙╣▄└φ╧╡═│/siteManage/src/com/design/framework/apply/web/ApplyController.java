package com.design.framework.apply.web;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.design.base.utils.BaseController;
import com.design.framework.apply.model.Apply;
import com.design.framework.apply.service.ApplyService;
import com.design.framework.site.service.SiteService;
@Controller
@Scope("prototype")
@RequestMapping("/sys/apply")
public class ApplyController extends BaseController {
    
	private final static String URL_APPLY_GETCHART = "/getChart";
	private final static String URL_APPLY_CHANGETYPE = "/changeType";
	private final static String URL_APPLY_USELIST = "/useList";
	private final static String JSP_APPLY_USELIST = "jsp/apply/useList";
	private final static String URL_APPLY_CHARTLIST = "/chartList";
	private final static String JSP_APPLY_CHARTLIST = "jsp/apply/chartList";
	private final static String URL_APPLY_PEOPLELIST = "/peopleList";
	private final static String JSP_APPLY_PEOPLELIST = "jsp/apply/peopleList";
	private final static String URL_APPLY_TIMELIST = "/timeList";
	private final static String JSP_APPLY_TIMELIST = "jsp/apply/timeList";
	private final static String URL_APPLY_LIST = "/list";
	private final static String JSP_APPLY_LIST = "jsp/apply/list";
	private final static String URL_APPLY_WITHDRAWLIST = "/withdrawList";
	private final static String JSP_APPLY_WITHDRAWLIST = "jsp/apply/withdrawList";
	private final static String URL_APPLY_HISTORYLIST = "/historyList";
	private final static String JSP_APPLY_HISTORYLIST = "jsp/apply/historyList";
    private final static String URL_APPLY_ADD = "/add";
    private final static String JSP_APPLY_ADD = "jsp/apply/add";
    private final static String URL_APPLY_DELETE = "/delete/{apply_id}";
    
    
    @Autowired
    private ApplyService applyService ;
    
    @Autowired
    private SiteService siteService ;
    
    
    @GetMapping(URL_APPLY_CHANGETYPE)
    public String changeType(Apply apply){
    	this.applyService.update(apply);
    	return "redirect:/sys/apply/list";
    }
    
    @GetMapping(URL_APPLY_CHARTLIST)
    public String chartList(){
    	return JSP_APPLY_CHARTLIST;
    }
    
    @GetMapping(URL_APPLY_GETCHART)
    @ResponseBody
    public List<Map<String,Object>> getChart(){
    	
    	return this.applyService.chartList();
    }
    
    @GetMapping(URL_APPLY_USELIST)
    public String useList(Model model){
    	model.addAttribute("applyList" , this.applyService.useList());
    	return JSP_APPLY_USELIST;
    }
    
    @GetMapping(URL_APPLY_PEOPLELIST)
    public String peopleList(Model model){
    	model.addAttribute("applyList" , this.applyService.peopleList());
    	return JSP_APPLY_PEOPLELIST;
    }
    
    @GetMapping(URL_APPLY_TIMELIST)
    public String timeList(Model model){
    	model.addAttribute("applyList" , this.applyService.timeList());
    	return JSP_APPLY_TIMELIST;
    }
    
    @GetMapping(URL_APPLY_LIST)
    public String list(Integer user_id,Model model){
    	model.addAttribute("applyList" , this.applyService.list());
    	return JSP_APPLY_LIST;
    }
    
    @GetMapping(URL_APPLY_WITHDRAWLIST)
    public String withdrawList(Integer user_id,Model model){
    	model.addAttribute("applyList" , this.applyService.withdrawList(user_id));
    	return JSP_APPLY_WITHDRAWLIST;
    }
    
    @GetMapping(URL_APPLY_HISTORYLIST)
    public String historyList(Integer user_id,Model model){
    	model.addAttribute("applyList" , this.applyService.historyList(user_id));
    	return JSP_APPLY_HISTORYLIST;
    }
    
    @GetMapping(URL_APPLY_DELETE)
    public String delete(@PathVariable("apply_id") Integer apply_id,String user_id){
        this.applyService.delete(apply_id);
        return "redirect:/sys/apply/withdrawList?user_id="+user_id;
    }

    
    @GetMapping(URL_APPLY_ADD)
    public String add(Model model){
    	model.addAttribute("siteList" , this.siteService.list(null));
        return JSP_APPLY_ADD;
    }
    @PostMapping(URL_APPLY_ADD)
    public String add(Apply apply,Model model){
        try{
            this.applyService.add(apply);
            model.addAttribute("addMessage" , "申请成功，请等待回复");
        }catch(Exception e){
        	model.addAttribute("addMessage" , "申请失败失败,原因为:"+e.getMessage());
        }
        model.addAttribute("siteList" , this.siteService.list(null));
        return JSP_APPLY_ADD;
    }

    
}
