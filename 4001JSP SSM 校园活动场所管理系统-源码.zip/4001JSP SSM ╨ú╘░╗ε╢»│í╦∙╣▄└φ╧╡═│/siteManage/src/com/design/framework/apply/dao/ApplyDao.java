/**
 * ApplyDao.java
 * ©2006-2016 四海兴唐科技有限公司 
 * All rights reserved.
 * <link>胖先生作品</link>
 * 创建于: 2017-04-11 21:13:17
 **/
package com.design.framework.apply.dao;

import java.util.List;
import java.util.Map;

import com.design.framework.apply.model.Apply;

public interface ApplyDao {
    int delete(Integer a_id);

    int add(Apply apply);

    Apply load(Integer a_id);

    int update(Apply apply);
    
    List<Apply> list();
    
    List<Apply> useList();
    
    List<Apply> peopleList();
    
    List<Apply> timeList();
    
    List<Map<String, Object>> chartList();
    
    List<Apply> withdrawList(Integer user_id);
    
    List<Apply> historyList(Integer user_id);
}