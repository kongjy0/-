package com.design.framework.apply.service;


import java.util.List;
import java.util.Map;

import com.design.framework.apply.model.Apply;


public interface ApplyService {
    /**
     *
     * FunName: login
     * Description : 用户登录
     * @param：String account,String password
     * @return Apply
     * @Author: pangsir
     * @Create Date: 2016-10-26
     */


    public void add(Apply apply);

    public List<Apply> list();
    
    public List<Apply> useList();
    
    public List<Apply> peopleList();
    
    public List<Apply> timeList();

    public List<Map<String, Object>> chartList();
    
    int delete(Integer mt_id);
    
    public List<Apply> withdrawList(Integer user_id);

    public List<Apply> historyList(Integer user_id);
    
    int update(Apply apply);
}
