/**
 * Apply.java
 * ©2006-2016 四海兴唐科技有限公司 
 * All rights reserved.
 * <link>胖先生作品</link>
 * 创建于: 2017-04-11 21:13:17
 **/
package com.design.framework.apply.model;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.design.framework.site.model.Site;
import com.design.framework.user.model.User;

/**
 * apply 类
 * @Description : 
 * 
 * @version 1.0 
 * 文件创建于: 2017-04-11 21:13:17
 **/
public class Apply {

    private Integer a_id;
    private Integer s_id;
    private Integer user_id;
    private String reason;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date starTime;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date endTime;
    private Integer a_type;
    private Integer ext1_int;
    private String ext2_varchar;
    private User user;
    private Site site;
    private Integer countNum;

	public Integer getCountNum() {
		return countNum;
	}

	public void setCountNum(Integer countNum) {
		this.countNum = countNum;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Site getSite() {
		return site;
	}

	public void setSite(Site site) {
		this.site = site;
	}

	/**
     * 获取  字段:apply.a_id
     *
     * @return  apply.a_id
     */
    public Integer getA_id() {
        return a_id;
    }

    /**
     * 设置  字段:apply.a_id
     *
     * @param a_id  apply.a_id
     */
    public void setA_id(Integer a_id) {
        this.a_id = a_id;
    }

    /**
     * 获取  字段:apply.s_id
     *
     * @return  apply.s_id
     */
    public Integer getS_id() {
        return s_id;
    }

    /**
     * 设置  字段:apply.s_id
     *
     * @param s_id  apply.s_id
     */
    public void setS_id(Integer s_id) {
        this.s_id = s_id;
    }

    /**
     * 获取  字段:apply.user_id
     *
     * @return  apply.user_id
     */
    public Integer getUser_id() {
        return user_id;
    }

    /**
     * 设置  字段:apply.user_id
     *
     * @param user_id  apply.user_id
     */
    public void setUser_id(Integer user_id) {
        this.user_id = user_id;
    }

    /**
     * 获取  字段:apply.reason
     *
     * @return  apply.reason
     */
    public String getReason() {
        return reason;
    }

    /**
     * 设置  字段:apply.reason
     *
     * @param reason  apply.reason
     */
    public void setReason(String reason) {
        this.reason = reason == null ? null : reason.trim();
    }

    /**
     * 获取  字段:apply.starTime
     *
     * @return  apply.starTime
     */
    public Date getStarTime() {
        return starTime;
    }

    /**
     * 设置  字段:apply.starTime
     *
     * @param starTime  apply.starTime
     */
    public void setStarTime(Date starTime) {
        this.starTime = starTime;
    }

    /**
     * 获取  字段:apply.endTime
     *
     * @return  apply.endTime
     */
    public Date getEndTime() {
        return endTime;
    }

    /**
     * 设置  字段:apply.endTime
     *
     * @param endTime  apply.endTime
     */
    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    /**
     * 获取  字段:apply.a_type
     *
     * @return  apply.a_type
     */
    public Integer getA_type() {
        return a_type;
    }

    /**
     * 设置  字段:apply.a_type
     *
     * @param a_type  apply.a_type
     */
    public void setA_type(Integer a_type) {
        this.a_type = a_type;
    }

    /**
     * 获取  字段:apply.ext1_int
     *
     * @return  apply.ext1_int
     */
    public Integer getExt1_int() {
        return ext1_int;
    }

    /**
     * 设置  字段:apply.ext1_int
     *
     * @param ext1_int  apply.ext1_int
     */
    public void setExt1_int(Integer ext1_int) {
        this.ext1_int = ext1_int;
    }

    /**
     * 获取  字段:apply.ext2_varchar
     *
     * @return  apply.ext2_varchar
     */
    public String getExt2_varchar() {
        return ext2_varchar;
    }

    /**
     * 设置  字段:apply.ext2_varchar
     *
     * @param ext2_varchar  apply.ext2_varchar
     */
    public void setExt2_varchar(String ext2_varchar) {
        this.ext2_varchar = ext2_varchar == null ? null : ext2_varchar.trim();
    }
}