package com.design.framework.apply.service.impl;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.design.framework.apply.dao.ApplyDao;
import com.design.framework.apply.model.Apply;
import com.design.framework.apply.service.ApplyService;


@Service
public class ApplyServiceImpl implements ApplyService {
    @Autowired
    private ApplyDao applyDao;
    
    @Override
    public void add(Apply apply) {
        try{
            this.applyDao.add(apply);
        }catch (Exception e) {
            throw new RuntimeException("更新失败,原因为:"+e.getMessage());
        }
        
    }
    
    @Override
    public List<Apply> list() {
        return this.applyDao.list();
    }
    
    @Override
    public int delete(Integer mt_id) {
        return this.applyDao.delete(mt_id);
    }

	@Override
	public List<Apply> withdrawList(Integer user_id) {
		return this.applyDao.withdrawList(user_id);
	}
    
	@Override
	public List<Apply> historyList(Integer user_id) {
		return this.applyDao.historyList(user_id);
	}

	@Override
	public int update(Apply apply) {
		return this.applyDao.update(apply);
	}

	@Override
	public List<Apply> peopleList() {
		return this.applyDao.peopleList();
	}

	@Override
	public List<Apply> timeList() {
		return this.applyDao.timeList();
	}

	@Override
	public List<Map<String, Object>> chartList() {
		return this.applyDao.chartList();
	}

	@Override
	public List<Apply> useList() {
		return this.applyDao.useList();
	}
	

    
}
