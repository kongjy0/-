package com.design.framework.message.service.impl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.design.framework.message.dao.MessageDao;
import com.design.framework.message.model.Message;
import com.design.framework.message.service.MessageService;


@Service
public class MessageServiceImpl implements MessageService {
    @Autowired
    private MessageDao messageDao;
    
    @Override
    public void add(Message message) {
        try{
            this.messageDao.add(message);
        }catch (Exception e) {
            throw new RuntimeException("更新失败,原因为:"+e.getMessage());
        }
        
    }
    
    @Override
    public List<Message> list() {
        return this.messageDao.list();
    }
    
    @Override
    public int delete(Integer m_id) {
        return this.messageDao.delete(m_id);
    }

	@Override
	public int update(Message message) {
		return this.messageDao.update(message);
	}

	@Override
	public Message load(Integer m_id) {
		return this.messageDao.load(m_id);
	}
    

    
}
