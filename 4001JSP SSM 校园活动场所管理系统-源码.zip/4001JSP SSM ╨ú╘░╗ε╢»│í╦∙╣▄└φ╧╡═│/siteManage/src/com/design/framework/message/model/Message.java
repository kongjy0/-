/**
 * Message.java
 * ©2006-2016 四海兴唐科技有限公司 
 * All rights reserved.
 * <link>胖先生作品</link>
 * 创建于: 2017-04-12 15:21:25
 **/
package com.design.framework.message.model;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.design.framework.user.model.User;

/**
 * message 类
 * @Description : 
 * 
 * @author 胖先生
 * @version 1.0 
 * 文件创建于: 2017-04-12 15:21:25
 **/
public class Message {

    private Integer m_id;
    private Integer user_id;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date time;
    private String message;
    private String reply;
    private User user;
    

    public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	/**
     * 获取  字段:message.m_id
     *
     * @return  message.m_id
     */
    public Integer getM_id() {
        return m_id;
    }

    /**
     * 设置  字段:message.m_id
     *
     * @param m_id  message.m_id
     */
    public void setM_id(Integer m_id) {
        this.m_id = m_id;
    }

    /**
     * 获取  字段:message.user_id
     *
     * @return  message.user_id
     */
    public Integer getUser_id() {
        return user_id;
    }

    /**
     * 设置  字段:message.user_id
     *
     * @param user_id  message.user_id
     */
    public void setUser_id(Integer user_id) {
        this.user_id = user_id;
    }

    /**
     * 获取  字段:message.time
     *
     * @return  message.time
     */
    public Date getTime() {
        return time;
    }

    /**
     * 设置  字段:message.time
     *
     * @param time  message.time
     */
    public void setTime(Date time) {
        this.time = time;
    }

    /**
     * 获取  字段:message.message
     *
     * @return  message.message
     */
    public String getMessage() {
        return message;
    }

    /**
     * 设置  字段:message.message
     *
     * @param message  message.message
     */
    public void setMessage(String message) {
        this.message = message == null ? null : message.trim();
    }

    /**
     * 获取  字段:message.reply
     *
     * @return  message.reply
     */
    public String getReply() {
        return reply;
    }

    /**
     * 设置  字段:message.reply
     *
     * @param reply  message.reply
     */
    public void setReply(String reply) {
        this.reply = reply == null ? null : reply.trim();
    }
}