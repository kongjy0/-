package com.design.framework.message.service;


import java.util.List;

import com.design.framework.message.model.Message;


public interface MessageService {
    /**
     *
     * FunName: login
     * Description : 用户登录
     * @param：String account,String password
     * @return Message
     * @Author: pangsir
     * @Create Date: 2016-10-26
     */


    public void add(Message message);

    public List<Message> list();

    public int delete(Integer m_id);
    
    public int update(Message message);
    
    public Message load(Integer m_id);

}
