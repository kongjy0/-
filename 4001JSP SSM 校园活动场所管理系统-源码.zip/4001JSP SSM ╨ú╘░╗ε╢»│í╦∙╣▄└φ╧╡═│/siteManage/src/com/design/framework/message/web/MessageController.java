package com.design.framework.message.web;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.design.base.utils.BaseController;
import com.design.framework.message.model.Message;
import com.design.framework.message.service.MessageService;
@Controller
@Scope("prototype")
@RequestMapping("/sys/message")
public class MessageController extends BaseController {
    
    private final static String URL_MESSAGE_LIST = "/list";
    private final static String JSP_MESSAGE_LIST = "jsp/message/list";
    private final static String URL_MESSAGE_ADD = "/add";
    private final static String JSP_MESSAGE_ADD = "jsp/message/add";
    private final static String URL_MESSAGE_DELETE = "/delete/{m_id}";
    private final static String JSP_MESSAGE_DELETE = "redirect:/sys/message/list";
    private final static String URL_MESSAGE_TOUPDATE = "/update/{message_id}";
    private final static String JSP_MESSAGE_TOUPDATE = "jsp/message/update";
    private final static String URL_MESSAGE_UPDATE = "/update";
    
    
    @Autowired
    private MessageService messageService ;
    
    @GetMapping(URL_MESSAGE_TOUPDATE)
    public String update(@PathVariable("message_id") Integer message_id,Model model){
        model.addAttribute("message" , this.messageService.load(message_id));
        return JSP_MESSAGE_TOUPDATE;
    }

    @PostMapping(URL_MESSAGE_UPDATE)
    @ResponseBody
    public Map<String,Object> update(Message message){
        Map<String , Object> map = new HashMap<String , Object>();
        try{
            this.messageService.update(message);
            map.put("flag" , "success");
        }catch(Exception e){
            map.put("message" , e.getMessage());
        }
        return map;
    }
    
    @GetMapping(URL_MESSAGE_DELETE)
    public String delete(@PathVariable("m_id") Integer m_id){
        this.messageService.delete(m_id);
        return JSP_MESSAGE_DELETE;
    }

    @GetMapping(URL_MESSAGE_LIST)
    public String list(Model model){
        model.addAttribute("messageList" , this.messageService.list());
        return JSP_MESSAGE_LIST;
    }
    @GetMapping(URL_MESSAGE_ADD)
    public String add(){
        return JSP_MESSAGE_ADD;
    }
    @PostMapping(URL_MESSAGE_ADD)
    @ResponseBody
    public Map<String,Object> add(Message message){
        Map<String , Object> map = new HashMap<String , Object>();
        try{
            this.messageService.add(message);
            map.put("flag" , "success");
        }catch(Exception e){
            map.put("message" , e.getMessage());
        }
        return map;
    }

    
}
