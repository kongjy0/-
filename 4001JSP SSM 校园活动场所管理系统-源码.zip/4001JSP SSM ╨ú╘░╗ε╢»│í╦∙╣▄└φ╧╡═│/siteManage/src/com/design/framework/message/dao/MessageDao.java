/**
 * MessageDao.java
 * ©2006-2016 四海兴唐科技有限公司 
 * All rights reserved.
 * <link>胖先生作品</link>
 * 创建于: 2017-04-12 15:21:25
 **/
package com.design.framework.message.dao;

import java.util.List;

import com.design.framework.message.model.Message;

public interface MessageDao {
    int delete(Integer m_id);

    int add(Message message);

    Message load(Integer m_id);

    int update(Message message);
    
    public List<Message> list();
}