package com.design.framework.site.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.design.framework.site.model.Site;
import com.design.framework.site.service.SiteService;


@Controller
@Scope("prototype")
@RequestMapping("/sys/site")
public class SiteController {

	private final static String URL_SITE_INFOLIST = "/infoList";
	private final static String JSP_SITE_INFOLIST = "jsp/site/infoList";
	private final static String URL_SITE_TYPELIST = "/typeList";
	private final static String JSP_SITE_TYPELIST = "jsp/site/typeList";
    private final static String URL_SITE_LIST = "/list";
    private final static String JSP_SITE_LIST = "jsp/site/list";
    private final static String URL_SITE_ADD = "/add";
    private final static String JSP_SITE_ADD = "jsp/site/add";
    private final static String URL_SITE_DELETE = "/delete/{s_id}";
    private final static String URL_SITE_TOUPDATE = "/update/{s_id}";
    private final static String JSP_SITE_TOUPDATE = "jsp/site/update";
    private final static String URL_SITE_UPDATE = "/update";

    @Autowired
    private SiteService siteService;

    @GetMapping(URL_SITE_INFOLIST)
    public String infoList(Model model,String key){
    	model.addAttribute("siteList" , this.siteService.list(key==""?null:key));
    	model.addAttribute("key" , key);
    	return JSP_SITE_INFOLIST;
    }
    
    @GetMapping(URL_SITE_TYPELIST)
    public String typeList(Model model,String key){
    	model.addAttribute("siteList" , this.siteService.list(key==""?null:key));
    	model.addAttribute("key" , key);
    	return JSP_SITE_TYPELIST;
    }
    
    @GetMapping(URL_SITE_LIST)
    public String list(Model model,String key){
    	model.addAttribute("siteList" , this.siteService.list(key==""?null:key));
    	model.addAttribute("key" , key);
    	return JSP_SITE_LIST;
    }

    @GetMapping(URL_SITE_TOUPDATE)
    public String update(@PathVariable("s_id") Integer s_id,Model model){
        model.addAttribute("site" , this.siteService.load(s_id));
        return JSP_SITE_TOUPDATE;
    }
    
    @PostMapping(URL_SITE_UPDATE)
    public String update(Site site){
        this.siteService.update(site);
        return "redirect:/sys/site/list";
    }
    
    @GetMapping(URL_SITE_ADD)
    public String add(Model model){
        return JSP_SITE_ADD;
    }

    @PostMapping(URL_SITE_ADD)
    public String add(Site site,ModelMap modelMap){
        try{
            this.siteService.add(site);
            modelMap.addAttribute("addMessage" , "添加成功");
        }catch(Exception e){
            modelMap.addAttribute("addMessage" , "添加失败,原因为:"+e.getMessage());
        }

        return JSP_SITE_ADD;
    }



    @GetMapping(URL_SITE_DELETE)
    public String delete(@PathVariable("s_id") Integer s_id){
        this.siteService.delete(s_id);
        return "redirect:/sys/site/list";
    }

}
