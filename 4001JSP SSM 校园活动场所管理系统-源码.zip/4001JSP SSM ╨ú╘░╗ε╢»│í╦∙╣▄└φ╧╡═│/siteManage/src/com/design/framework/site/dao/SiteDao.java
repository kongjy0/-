/**
 * SiteDao.java
 * ©2006-2016 四海兴唐科技有限公司 
 * All rights reserved.
 * <link>胖先生作品</link>
 * 创建于: 2017-04-11 16:18:15
 **/
package com.design.framework.site.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.design.framework.site.model.Site;

public interface SiteDao {
	
	int delete(Integer s_id);

    int add(Site site);

    Site load(Integer s_id);

    int update(Site site);

    List<Site> list(@Param("key")String key);
}