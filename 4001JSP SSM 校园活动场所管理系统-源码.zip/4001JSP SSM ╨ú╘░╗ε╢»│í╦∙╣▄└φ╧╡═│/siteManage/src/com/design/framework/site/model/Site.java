/**
 * Site.java
 * ©2006-2016 四海兴唐科技有限公司 
 * All rights reserved.
 * <link>胖先生作品</link>
 * 创建于: 2017-04-11 16:18:15
 **/
package com.design.framework.site.model;

/**
 * site 类
 * @Description : 
 * 
 * @author 胖先生
 * @version 1.0 
 * 文件创建于: 2017-04-11 16:18:15
 **/
public class Site {

    private Integer s_id;
    private String s_name;
    private String requires;
    private Integer s_type;
    private Integer ext1_int;
    private String ext2_varchar;

    /**
     * 获取  字段:site.s_id
     *
     * @return  site.s_id
     */
    public Integer getS_id() {
        return s_id;
    }

    /**
     * 设置  字段:site.s_id
     *
     * @param s_id  site.s_id
     */
    public void setS_id(Integer s_id) {
        this.s_id = s_id;
    }

    /**
     * 获取  字段:site.s_name
     *
     * @return  site.s_name
     */
    public String getS_name() {
        return s_name;
    }

    /**
     * 设置  字段:site.s_name
     *
     * @param s_name  site.s_name
     */
    public void setS_name(String s_name) {
        this.s_name = s_name == null ? null : s_name.trim();
    }

    /**
     * 获取  字段:site.requires
     *
     * @return  site.requires
     */
    public String getRequires() {
        return requires;
    }

    /**
     * 设置  字段:site.requires
     *
     * @param requires  site.requires
     */
    public void setRequires(String requires) {
        this.requires = requires == null ? null : requires.trim();
    }

    /**
     * 获取  字段:site.s_type
     *
     * @return  site.s_type
     */
    public Integer getS_type() {
        return s_type;
    }

    /**
     * 设置  字段:site.s_type
     *
     * @param s_type  site.s_type
     */
    public void setS_type(Integer s_type) {
        this.s_type = s_type;
    }

    /**
     * 获取  字段:site.ext1_int
     *
     * @return  site.ext1_int
     */
    public Integer getExt1_int() {
        return ext1_int;
    }

    /**
     * 设置  字段:site.ext1_int
     *
     * @param ext1_int  site.ext1_int
     */
    public void setExt1_int(Integer ext1_int) {
        this.ext1_int = ext1_int;
    }

    /**
     * 获取  字段:site.ext2_varchar
     *
     * @return  site.ext2_varchar
     */
    public String getExt2_varchar() {
        return ext2_varchar;
    }

    /**
     * 设置  字段:site.ext2_varchar
     *
     * @param ext2_varchar  site.ext2_varchar
     */
    public void setExt2_varchar(String ext2_varchar) {
        this.ext2_varchar = ext2_varchar == null ? null : ext2_varchar.trim();
    }
}