package com.design.framework.site.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.design.framework.site.dao.SiteDao;
import com.design.framework.site.model.Site;
import com.design.framework.site.service.SiteService;
@Service
public class SiteServiceImpl implements SiteService {
    @Autowired
    private SiteDao siteDao;

    @Override
    public int delete(Integer s_id) {
        return this.siteDao.delete(s_id);
    }

    @Override
    public int add(Site site) {
        return this.siteDao.add(site);
    }

    @Override
    public Site load(Integer s_id) {
        return this.siteDao.load(s_id);
    }

    @Override
    public int update(Site site) {
        return this.siteDao.update(site);
    }

    @Override
    public List<Site> list(String key) {
        return this.siteDao.list(key);
    }

}
