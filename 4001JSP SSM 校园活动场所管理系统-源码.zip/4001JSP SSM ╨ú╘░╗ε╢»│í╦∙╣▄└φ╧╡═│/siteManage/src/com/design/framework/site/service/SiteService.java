package com.design.framework.site.service;

import java.util.List;

import com.design.framework.site.model.Site;

public interface SiteService {
    
    int delete(Integer s_id);

    int add(Site site);

    Site load(Integer s_id);

    int update(Site site);

    List<Site> list(String key);
}
