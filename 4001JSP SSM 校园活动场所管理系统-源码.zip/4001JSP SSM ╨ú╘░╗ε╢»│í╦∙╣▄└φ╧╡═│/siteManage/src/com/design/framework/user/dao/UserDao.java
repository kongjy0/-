/**
 * UserDao.java
 * ©2006-2016 四海兴唐科技有限公司
 * All rights reserved.
 * <link>胖先生作品</link>
 * 创建于: 2017-04-10 23:48:54
 **/
package com.design.framework.user.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.design.framework.user.model.User;

public interface UserDao {
    int delete(Integer user_id);

    int add(User user);

    User load(Integer user_id);

    int update(User user);
    
    List<User> list();
    
    List<User> auditList();

    User login( @Param("account") String account,@Param("password") String password);
    
    User loadAccount(String user_account);
}