package com.design.framework.user.web;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.design.base.utils.BaseController;
import com.design.framework.user.model.User;
import com.design.framework.user.service.UserService;


@Controller
@Scope("prototype")
@RequestMapping("/sys/user")
public class UserController extends BaseController{
    
	private final static String URL_USER_SHOW = "/show";
	private final static String JSP_USER_SHOW = "jsp/user/show";
    private final static String URL_USER_FORGET = "/forget";
    private final static String JSP_USER_FORGET = "jsp/user/forget";
    private final static String URL_USER_LIST = "/list";
    private final static String JSP_USER_LIST = "jsp/user/list";
    private final static String URL_USER_CHANGETYPE = "/changeType";
    private final static String URL_USER_AUDIT = "/audit";
    private final static String JSP_USER_AUDIT = "jsp/user/audit";
    private final static String URL_USER_ADD = "/add";
    private final static String JSP_USER_ADD = "jsp/user/add";
    private final static String URL_USER_DELETE = "/delete/{user_id}";
    private final static String URL_USER_CHECKID = "/checkId";
    private final static String URL_USER_CHECKACCOUNT = "/checkAccount";
    private final static String URL_USER_CHANGEPASSWORD = "/changePassword";
    private final static String JSP_USER_CHANGEPASSWORD = "jsp/user/changePassword";
    private final static String URL_USER_TOUPDATE = "/update/{user_id}";
    private final static String JSP_USER_TOUPDATE = "jsp/user/update";
    private final static String URL_USER_UPDATE = "/update";
    
    @Autowired
    private UserService userService;
    
    @GetMapping(URL_USER_SHOW)
    public String show(String photo,Model model){
    	model.addAttribute("photo" , photo);
    	return JSP_USER_SHOW;
    }
    
    @GetMapping(URL_USER_TOUPDATE)
    public String update(@PathVariable("user_id") Integer user_id,Model model){
        model.addAttribute("user" , this.userService.load(user_id));
        return JSP_USER_TOUPDATE;
    }

    
    @PostMapping(URL_USER_UPDATE)
    public String changePassword(User user){
        this.userService.update(user);
        return "redirect:/sys/user/list";
    }

    @GetMapping(URL_USER_FORGET)
    public String forget(){
        return JSP_USER_FORGET;
    }
    
    @PostMapping(URL_USER_FORGET)
    public String forget(User user,ModelMap modelMap){
        modelMap.addAttribute("forgetMessage" , this.userService.forget(user));
        modelMap.addAttribute("user" , user);
        return JSP_USER_FORGET;
    }

    @GetMapping(URL_USER_CHANGEPASSWORD)
    public String changePassword(){
        return JSP_USER_CHANGEPASSWORD;
    }

    @PostMapping(URL_USER_CHANGEPASSWORD)
    public String changePassword(User user,ModelMap modelMap,HttpServletRequest request){
        this.userService.update(user);

        HttpSession session = request.getSession();
        User newUser = (User)session.getAttribute("session_user");
        newUser.setUser_password(user.getUser_password());
        session.setAttribute("session_user" , newUser);

        modelMap.addAttribute("changeMessage" , "修改成功");
        return JSP_USER_CHANGEPASSWORD;
    }
    
    @GetMapping(URL_USER_ADD)
    public String add(){
        return JSP_USER_ADD;
    }
    
    @PostMapping(URL_USER_ADD)
    public String add(User user,@RequestParam(name="photo") MultipartFile photo,ModelMap modelMap){
        try{
            //获取文件名称
            String fileName = photo.getOriginalFilename();
            if(fileName!=null&&fileName.trim().length()>0){
                String path = this.application.getRealPath("/upload/");
                File folder = new File(path);
                if(!folder.exists()&&!folder.isDirectory()){
                    folder.mkdirs();
                }
                //获取文件的后缀名称
                String ext = FilenameUtils.getExtension(fileName);
                //新建名称
                String newFileName = (new Date().getTime())+"_"+(new Random().nextInt(10000))+"."+ext;
                
                File newFile = new File(path+"/"+newFileName);
                
                //完成上传操作
                photo.transferTo(newFile);

                user.setExt2_varchar(newFileName);
            }
            this.userService.add(user);
            modelMap.addAttribute("addMessage" , "添加成功,请等待审核");
        }catch(Exception e){
            modelMap.addAttribute("addMessage" , "添加失败,原因为:"+e.getMessage());
        }
        
        return JSP_USER_ADD;
    }
    
    @PostMapping(URL_USER_CHECKID)
    @ResponseBody
    public Map<String,Object> checkId(Integer user_id){
        Map<String , Object> map = new HashMap<String , Object>();
        if(this.userService.checkId(user_id)){
            map.put("flag" , "success");
        }else{
            
            map.put("flag" , "error");
        }
        return map;
    }

    @PostMapping(URL_USER_CHECKACCOUNT)
    @ResponseBody
    public Map<String,Object> checkAccount(String user_account){
        Map<String , Object> map = new HashMap<String , Object>();
        if(this.userService.checkAccount(user_account)){
            map.put("flag" , "success");
        }else{

            map.put("flag" , "error");
        }
        return map;
    }
    
    @GetMapping(URL_USER_LIST)
    public String list(Model model){
        model.addAttribute("userList" , this.userService.list());
        return JSP_USER_LIST;
    }
    
    @GetMapping(URL_USER_AUDIT)
    public String audit(Model model){
    	model.addAttribute("userList" , this.userService.auditList());
    	return JSP_USER_AUDIT;
    }
    
    @GetMapping(URL_USER_CHANGETYPE)
    public String changeType(User user){
    	this.userService.update(user);
    	return "redirect:/sys/user/audit";
    }
    
    @GetMapping(URL_USER_DELETE)
    public String delete(@PathVariable("user_id") Integer user_id){
        this.userService.delete(user_id);
        return "redirect:/sys/user/list";
    }
    
}
